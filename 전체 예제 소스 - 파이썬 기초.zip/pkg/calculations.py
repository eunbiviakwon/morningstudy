def add(l, r):
    return l + r


def mul(l, r):
    return l * r


def div(l, r):
    return l / r
